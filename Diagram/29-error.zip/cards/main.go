package main

func main() {
	cards := newDeckFromFile("my")
	cards.print()
}
